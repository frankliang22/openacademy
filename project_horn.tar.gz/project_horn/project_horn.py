 #-*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from datetime import datetime

from openerp import api
from openerp import SUPERUSER_ID
from openerp import tools
from openerp.osv import fields, osv, orm
from openerp.tools import DEFAULT_SERVER_DATETIME_FORMAT
from openerp.tools import html2plaintext
from openerp.tools.translate import _



 
class project(osv.Model):
    _inherit = "project.project"

    def action_rfq(self, cr, uid, ids, context=None):
        #set to mp state
        return self.write(cr,uid, ids, {'state':'rfq'}, context=context)
  
    def action_ko(self, cr, uid, ids, context=None):
        #set to mp state
        return self.write(cr,uid, ids, {'state':'ko'}, context=context)

    def action_proto(self, cr, uid, ids, context=None):
        #set to design state
        return self.write(cr,uid, ids, {'state':'proto'}, context=context)

    def action_evt(self, cr, uid, ids, context=None):
        #set to mp state
        return self.write(cr,uid, ids, {'state':'evt'}, context=context)
  
    def action_dvt(self, cr, uid, ids, context=None):
        #set to mp state
        return self.write(cr,uid, ids, {'state':'dvt'}, context=context)

    def action_pvt(self, cr, uid, ids, context=None):
        #set to design state
        return self.write(cr,uid, ids, {'state':'pvt'}, context=context)

    def action_mp(self, cr, uid, ids, context=None):
        #set to mp state
        return self.write(cr,uid, ids, {'state':'mp'}, context=context)
  
    def action_comp(self, cr, uid, ids, context=None):
        #set to mp state
        return self.write(cr,uid, ids, {'state':'comp'}, context=context)

    def action_can(self, cr, uid, ids, context=None):
        #set to design state
        return self.write(cr,uid, ids, {'state':'can'}, context=context)

    _columns = {
        
        'state': fields.selection([
            ('rfq','RFQ'),('ko','KO'),
            ('proto','Proto'),('evt','EVT'),
            ('dvt','DVT'),('pvt','PVT'),
            ('mp','MP'),('comp','Completed'),
            ('can','Cancelled'),
            ], string="Stage",),  
    }

    _defaults = {
        'state': 'rfq',
    }

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
